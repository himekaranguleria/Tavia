# Change Log
All notable changes to this project will be documented in this file.
This project adheres to [Semantic Versioning](http://semver.org/).

## [v0.2.2] - 10.08.2016

### Added
- Prevent to crash display if cronjobs are configured wrong

## [v0.2.0] - 20.07.2016

### Added
- Apache2 license
- First working adminhtml cronjob overivew

### Changed

- Add messages to cron item title